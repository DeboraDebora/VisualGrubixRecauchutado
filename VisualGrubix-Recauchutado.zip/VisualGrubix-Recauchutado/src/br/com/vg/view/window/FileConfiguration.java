/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.vg.view.window;

import java.awt.Color;

/**
 *
 * @author jesimar
 */
public class FileConfiguration {
    
    private Integer SizeNodes;
    private Color colorNodeDefault;
    private Color colorLinesGraph;
    private Color colorBackground;
    private Color colorEnvioPacket;
    private Color colorEnvioAck;
    
    public FileConfiguration(){
        
    }
    
    
    
}
