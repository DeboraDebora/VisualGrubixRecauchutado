/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.vg.view.window;

/**
 *
 * @author jesimar
 */
public interface iConstants {
    
    //---------------------------------FLAGS------------------------------------

    //Flags de controle da interface gráfica.
    
    /**
     * Indica o modo da simulação como: corrente.
     */
    public static final byte OPEN_XML_NORMAL = 0;
    
    public static final byte OPEN_XML_TIME_REAL = 1;       
    
    public static final Integer SIZE_MAX_NODE = 1000;
    
    public static final Integer SIZE_MIN_NODE = 1;
    
    public static final int INGLES = 1;
    
    public static final int PORTUGUES = 2;
            
}
