package br.com.vg.view.others;

import java.awt.*;
import java.awt.color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.UIManager.LookAndFeelInfo;

 //@author Débora Rossini 
 
 public class AccessibilityMode extends TabAbstract {
 
	private String foreground;
	private String background;
	private String buttonColor; //no protótipo tem algumas cinza por erro do figma mas é black pra tudo 
	private String nodeColor;
	private String simulationBackground      ; //a area do painel de visualização
	private String radiusColor; //cor dos sinais de rádio
	private String graphConnectivityColor; //sugestão de cor do grafo ser alterada
	private byte acessibilityMode = ACESSIBILITY_MODE_DISABLE; 
	
	private double sizeButton; //uma função que aumenta do original % da classe ButtonsAbstract, reescrevendo as dimensões 
	
	//construtor
	public AccessibilityMode (String foreground, String background, String buttonColor, String nodeColor, string radiusColor, String graphConnectivityColor, double sizeButton){
		this.foreground = WHITE;
		this.background = GREY;
		this.buttonColor = BLACK;
		this.nodeColor = YELLOW;
		this.simulationBackground = BLACK; 
		this.radiusColor = GREEN;
		this.graphConnectivityColor = PINK;
		//this.sizeButton = tentar colocar uma fórmula que coloca o tamanho proporcional)
	}
	
	//declarando getter
	public String getAccessibilityMode(){
		return accessibilityMode;
	}
	
 
	//construtor padrão 
     LookAndFeels acessibilityMode = new LookAndFeels();
     
    
     
 };
