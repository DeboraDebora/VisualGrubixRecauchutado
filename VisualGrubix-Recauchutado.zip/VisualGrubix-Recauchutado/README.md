# VisualGrubix

Versão atualizada do visualizador de simulações computacionais do Framework Grubix para Redes de Sensores Sem Fio (RSSF).

Desenvolvedores: Jesimar da Silva Arantes, Débora Rossini

![](./img/img00.png)

![](./img/img01.png)

Para mais informações acesse os materiais: 

[TCC sobre o VisualGrubix](./manuais/TCC-Jesimar-SI-UFLA-VisualGrubix.pdf)

[Manual do Grubix](./manuais/ManualGrubix.pdf)

[Manual do VisualGrubix](./manuais/ManualVisualizador.pdf)
